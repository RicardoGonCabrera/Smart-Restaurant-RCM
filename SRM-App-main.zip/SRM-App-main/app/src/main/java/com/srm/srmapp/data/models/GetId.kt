package com.srm.srmapp.data.models

interface GetId {
    // Get ID from object
    fun getId(): Int

}