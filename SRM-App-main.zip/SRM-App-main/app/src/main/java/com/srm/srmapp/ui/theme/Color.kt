package com.srm.srmapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val ButtonColor1 = Color(0xFF3D4545)
val ButtonColor2 = Color(0xFF271A1A)
val DialogBackground = Color(0xFFFFFFFF)
val TextColor = Color(0xFFFFFFFF)
val Teal200 = Color(0xFF03DAC5)