import warnings
import numpy as np
import pandas as pd
import datetime
import json
import holidays
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
from keras.layers import Dense, LSTM, RepeatVector, TimeDistributed, Flatten, Dropout
from keras.models import load_model, Sequential, Model
from keras.utils.np_utils import to_categorical
from flask import Flask, jsonify
from flask_restful import Resource, Api
from flask_cors import CORS
import tensorflow as tf
import threading 

app = Flask(__name__)
api = Api(app)
CORS(app)

warnings.simplefilter(action='ignore', category=FutureWarning)


class status (Resource):
    def get(self):
        try:
            return {'data': 'Api is Running'}
        except:
            return {'data': 'An Error Occurred during fetching Api'}


class SRM_Retrain_Customers(Resource):
    def get(self):
	
	data=requests.get('https://smart-restaurant-manager.herokuapp.com/api/v1/ai/data').json()
  	data = list(data.values())[0]
 	df = []
  	for i in data:
    		for j in i['food_types']:
      			df.append([i['date'], j, i['festive'],1])
  	df=pd.DataFrame(df, columns=['Date', 'Item Name', 'Festive', 'Quantity'])


  	df.loc[df['Festive'] == False, 'Festive'] = 0
  	df.loc[df['Festive'] == True, 'Festive'] = 1


	df['Date'] = pd.to_datetime(df['Date']).dt.date
	df['Day'] = pd.to_datetime(df['Date']).dt.dayofweek
	df['Season'] = pd.to_datetime(df['Date']).dt.month % 12 // 3 + 1
	df['numDay'] = pd.to_datetime(df['Date']).dt.day
	df['numMonth'] = pd.to_datetime(df['Date']).dt.month
        
        df = df.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Season'], as_index=False)['Quantity'].sum()

        labels = df['Quantity']
        df = df.drop('Quantity', axis=1)
        x=np.asarray(df).astype(np.float32)
        y=np.asarray(labels).astype(np.float32)


        X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
        
        # MLP for Time Series Forecasting
        epochs = 400
        lr = 0.0003
        adam = tf.keras.optimizers.Adam(lr)

        model_mlp = Sequential()
        model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
        model_mlp.add(Dense(1))
        model_mlp.compile(loss='mse', optimizer=adam)
        model_mlp.summary()

        thread = threading.Thread(target=self.fit_customers, kwargs={'model_mlp':model_mlp, 'X_train':X_train, 'Y_train':Y_train, 'X_valid':X_valid, 'Y_valid':Y_valid, 'epochs':epochs})
        thread.start()
	
        return jsonify("Done")
        
        
    def fit_customers(self, model_mlp, X_train, Y_train, X_valid, Y_valid, epochs):
        mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
        model_mlp.save('customers_model.h5')
        print("Model saved")

class SRM_Retrain_Food(Resource):
    def get(self):
        data=requests.get('https://smart-restaurant-manager.herokuapp.com/api/v1/ai/data').json()
  	data = list(data.values())[0]
 	train = []
  	for i in data:
    		for j in i['food_types']:
      			train.append([i['date'], j, i['festive'],1])
  	train=pd.DataFrame(train, columns=['Date', 'Item Name', 'Festive', 'Quantity'])


  	train.loc[train['Festive'] == False, 'Festive'] = 0
  	train.loc[train['Festive'] == True, 'Festive'] = 1


	train['Date'] = pd.to_datetime(train['Date']).dt.date
	train['Day'] = pd.to_datetime(train['Date']).dt.dayofweek
	train['Season'] = pd.to_datetime(train['Date']).dt.month % 12 // 3 + 1
	train['numDay'] = pd.to_datetime(train['Date']).dt.day
	train['numMonth'] = pd.to_datetime(train['Date']).dt.month

        # Final database
        df = train.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Item Name'], as_index=False)['Quantity'].sum()
        train = train.groupby(['numMonth', 'numDay', 'Day', 'Festive'], as_index=False)['Quantity'].sum()
        newdf = pd.DataFrame([])
        
        
        for j in train['numDay']:
            for i in train['numMonth'].unique():
                x = df.loc[(df.numMonth == i) & (df.numDay == j)]
                if not x.empty:
                    x = x[x.Quantity == x.Quantity.max()].iloc[0]
                    newdf = newdf.append(x)

        aa=sorted(newdf['Item Name'].unique().tolist())
        with open('names.txt','w') as outfile:
            json.dump(aa, outfile)
        newdf = newdf.drop('Quantity', 1)
        lb = LabelEncoder()
        labels = np.asarray(newdf['Item Name'])

        newdf = newdf.drop('Item Name', axis=1)
        x = np.asarray(newdf).astype(np.float32)
        y = to_categorical(lb.fit_transform(labels))
        
        X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)

        epochs = 350
        batch = 256
        lr = 0.0003
        adam = tf.keras.optimizers.Adam(lr)

        model_mlp = Sequential()
        model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
        model_mlp.add(Dropout(0.1))
        model_mlp.add(Dense(128, activation='relu'))
        model_mlp.add(Dropout(0.25))
        model_mlp.add(Dense(np.size(Y_train[0]), activation='softmax'))
        model_mlp.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')
        model_mlp.summary()

        thread = threading.Thread(target=self.fit_food, kwargs={'model_mlp':model_mlp, 'X_train':X_train, 'Y_train':Y_train, 'X_valid':X_valid, 'Y_valid':Y_valid, 'epochs':epochs})
        thread.start()
        
        return jsonify("Done")
        
        
    def fit_food(self, model_mlp, X_train, Y_train, X_valid, Y_valid, epochs):
        mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
        model_mlp.save('food_model.h5')
        print("Model saved")


class SRM_Predict(Resource):
    def get(self, date, localevent, numreservados):
        numreservados = int(numreservados)
        date_time_obj = datetime.datetime.strptime(date, '%d-%m-%Y').date()
        month = date_time_obj.month
        day = date_time_obj.day
        weekday = date_time_obj.weekday()
        season = month % 12 // 3 + 1
        if localevent == 'No':
            localevent = 0
        else:
            localevent = 1
        customers_model = load_model('customers_model.h5')
        customer_flow = customers_model.predict(np.array([[month, day, weekday, localevent, season]]).astype(np.float32))[0][0]/1.5
        if customer_flow * 0.6 < numreservados:
            customer_flow = numreservados * 1.7
    
        food_model = load_model('food_model.h5')
        with open('names.txt') as json_file:
            names = json.load(json_file)
        food_predictions = food_model.predict(np.array([[month, day, weekday, localevent]]).astype(np.float32))
        prediction = np.argmax(food_predictions)
        food = names[prediction]
        final_prediction = str(customer_flow) + "%" + str(food)

        return jsonify(final_prediction)

api.add_resource(status, '/')
api.add_resource(SRM_Predict, '/srm-predict/<date>,<localevent>,<numreservados>')
api.add_resource(SRM_Retrain_Customers, '/srm-retrain-customers')
api.add_resource(SRM_Retrain_Food, '/srm-retrain-food')


if __name__ == '__main__':
    app.run()
