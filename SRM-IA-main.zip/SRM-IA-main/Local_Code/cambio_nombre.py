import pandas as pd
import numpy as np

train = pd.read_csv('restaurant-1-orders.csv', parse_dates=['Order Date'])
h=train['Item Name'].unique()

categorias=['Cereales', 'Carnico', 'Vegetales', 'Marisco', 'Especias', 'Otros']
matching = [s for s in np.asarray(train['Item Name']) if ('Papadum' or 'Naan') in s]
for i in range(len(list(set(matching)))):
    train.loc[train['Item Name'] == matching[i], 'Item Name'] = categorias[i]

nombres=['Chicken', 'Tikka', 'Lamb', 'Chicken', 'Sheek', 'Meat', 'Muttar', 'Shaslick']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Carnico'

nombres=['Chapati', 'Saag', 'Paratha']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Cereales'

nombres=['Prawn', 'Fish']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Marisco'

nombres=['Rice', 'Bhajee', 'Dhansak', 'Baingan', 'Puree', 'Cauliflower', 'Chana Masala', 'Bombay', 'Gobi', 'Bhindi', 'Onion', 'Fries', 'Mushroom', 'Salad', 'Vegetable']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Vegetales'

nombres=['Sauce', 'Madras', 'Kurma', 'Pathia', 'Korma', 'Dupiaza', 'Methi', 'Curry', 'Samba', 'Bhuna', 'Vindaloo', 'Raitha', 'Royal Paneer', 'Tandoori', 'Methi']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Especias'

nombres=['Chutney', 'Rogon', 'Cobra', 'COBRA', 'Pickle', 'Tarka Dall', 'Chaat', 'Mixed', 'wine', 'Lemonade', 'ltr', 'Water', 'Coke']
for c in nombres:
    matching = [s for s in np.asarray(train['Item Name']) if c in s]
    for i in list(set(matching)):
        train.loc[train['Item Name'] == i, 'Item Name']='Otros'




h=train['Item Name'].unique()

train.to_csv('dataframe.csv', index=False)
