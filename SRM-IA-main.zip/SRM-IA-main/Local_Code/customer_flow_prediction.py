import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import holidays
import datetime
import tensorflow as tf
from sklearn.model_selection import train_test_split
from keras.models import Sequential, Model, load_model
from keras.layers import Dense, LSTM, RepeatVector, TimeDistributed, Flatten
from sklearn.metrics import mean_squared_error


train = pd.read_csv('dataframe.csv', parse_dates=['Order Date'])

# -------------------- Data processing --------------------
# Date and time splitting
train['Date'] = train['Order Date'].dt.date
train['Time'] = train['Order Date'].dt.time
train = train.drop('Order Date', 1)

# Subsample to use only 2018 orders.
train = train[(train['Date'] > datetime.date(2018, 1, 1))]
train = train[(train['Date'] < datetime.date(2018, 12, 31))]
train = train.sort_values('Date')

# Creation of columns for application adaptation
train['Day'] = pd.to_datetime(train['Date']).dt.dayofweek
train['Season'] = pd.to_datetime(train['Date']).dt.month % 12 // 3 + 1
train['Festive'] = 0
uk_holidays = holidays.Spain()
for ptr, x in holidays.Spain(years=2018).items():
    train['Festive'][train['Date'] == ptr] = x
    train['Festive'][train['Date'] == ptr] = 1

train['numDay'] = pd.to_datetime(train['Date']).dt.day
train['numMonth'] = pd.to_datetime(train['Date']).dt.month



# -------------------- Data visualization --------------------
# daily_quantity = train.groupby(['Date'], as_index=False)['Quantity'].sum()
# plt.figure()
# plt.plot(daily_quantity['Date'], daily_quantity['Quantity'])
# plt.title('Daily sales')
# plt.show()
#
#
# seasons_quantity = train.groupby(['Season'], as_index=False)['Quantity'].sum()
# plt.figure()
# plt.plot(seasons_quantity['Season'], seasons_quantity['Quantity'])
# plt.title('Season sales')
# plt.xticks(seasons_quantity['Season'], ['Winter', 'Spring', 'Summer', 'Autumn'])
# plt.show()
#
#
# days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
# day_quantity = train.groupby(['Day'], as_index=False)['Quantity'].sum()
# day_quantity['Day'] = pd.Categorical(day_quantity['Day'], categories=days, ordered=True)
# day_quantity = day_quantity.sort_values('Day')
# plt.figure()
# plt.plot(day_quantity['Day'], day_quantity['Quantity'])
# plt.title('Day of week sales')
# plt.show()


# Final database
df = train.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Season'], as_index=False)['Quantity'].sum()

labels = df['Quantity']
df = df.drop('Quantity', axis=1)
x=np.asarray(df).astype(np.float32)
y=np.asarray(labels).astype(np.float32)


X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
print('Train set shape', X_train.shape)
print('Validation set shape', X_valid.shape)


# # MLP for Time Series Forecasting
# epochs = 400
# batch = 256
# lr = 0.0003
# adam = tf.keras.optimizers.Adam(lr)
#
# model_mlp = Sequential()
# model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
# model_mlp.add(Dense(1))
# model_mlp.compile(loss='mse', optimizer=adam)
# model_mlp.summary()
#
# mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
# model_mlp.save('customers_model.h5')
model_mlp=load_model('customers_model.h5')
mlp_train_pred = model_mlp.predict(X_train)
mlp_valid_pred = model_mlp.predict(X_valid)
print('Train rmse:', np.sqrt(mean_squared_error(Y_train, mlp_train_pred)))
print('Validation rmse:', np.sqrt(mean_squared_error(Y_valid, mlp_valid_pred)))
mlp_valid_pred/=1.5
Y_valid/=1.5
ac=0
for i in range(len(Y_valid)):
    print("Dia: ", int(X_valid[i][1]), '/', int(X_valid[i][0]), "Real: ",  Y_valid[i]/1.5, "Prediccion: ", mlp_valid_pred[i]/1.5)
    if (mlp_valid_pred[i] * 0.45) < Y_valid[i] < (mlp_valid_pred[i] * 1.55) or (mlp_valid_pred[i] - 25) < Y_valid[i] < (mlp_valid_pred[i] + 25):
        print("CORRECTO")
        ac+=1
    else:
        print("INCORRECTO")
print("Accuracy: ", ac/len(Y_valid))