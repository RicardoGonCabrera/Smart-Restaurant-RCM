import numpy as np
import pandas as pd
import holidays
import datetime
import tensorflow as tf
from sklearn.model_selection import train_test_split
from keras.models import Sequential, Model
from keras.layers import Dense, Dropout
from sklearn.metrics import mean_squared_error
from keras.utils.np_utils import to_categorical
from sklearn.preprocessing import LabelEncoder
import json
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)


train = pd.read_csv('dataframe.csv', parse_dates=['Order Date'])

# -------------------- Data processing --------------------
# Date and time splitting
train['Date'] = train['Order Date'].dt.date
train['Time'] = train['Order Date'].dt.time
train = train.drop('Order Date', 1)

# Subsample to use only 2018 orders.
train = train[(train['Date'] > datetime.date(2018, 1, 1))]
train = train[(train['Date'] < datetime.date(2018, 12, 31))]
train = train.sort_values('Date')

# Creation of columns for application adaptation
train['Day'] = pd.to_datetime(train['Date']).dt.dayofweek
train['Season'] = pd.to_datetime(train['Date']).dt.month % 12 // 3 + 1
train['Festive'] = 0
uk_holidays = holidays.Spain()
for ptr, x in holidays.Spain(years=2018).items():
    train['Festive'][train['Date'] == ptr] = x
    train['Festive'][train['Date'] == ptr] = 1

train['numDay'] = pd.to_datetime(train['Date']).dt.day
train['numMonth'] = pd.to_datetime(train['Date']).dt.month

# Final database
df = train.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Item Name'], as_index=False)['Quantity'].sum()
train = train.groupby(['numMonth', 'numDay', 'Day', 'Festive'], as_index=False)['Quantity'].sum()
newdf = pd.DataFrame([])

for j in train['numDay']:
    for i in train['numMonth'].unique():
        x = df.loc[(df.numMonth == i) & (df.numDay == j)]
        if not x.empty:
            x = x[x.Quantity == x.Quantity.max()].iloc[0]
            newdf = newdf.append(x)
            # newdf = pd.concat([newdf, x[x.Quantity == x.Quantity.max()].iloc[0]])


aa=sorted(newdf['Item Name'].unique().tolist())
with open('names.txt','w') as outfile:
    json.dump(aa, outfile)
newdf = newdf.drop('Quantity', 1)
lb = LabelEncoder()
labels = np.asarray(newdf['Item Name'])

newdf = newdf.drop('Item Name', axis=1)
x = np.asarray(newdf).astype(np.float32)
y = to_categorical(lb.fit_transform(labels))


X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
print('Train set shape', X_train.shape)
print('Validation set shape', X_valid.shape)


# MLP
epochs = 350
batch = 256
lr = 0.0003
adam = tf.keras.optimizers.Adam(lr)

model_mlp = Sequential()
model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
model_mlp.add(Dropout(0.1))
model_mlp.add(Dense(128, activation='relu'))
model_mlp.add(Dropout(0.25))
model_mlp.add(Dense(np.size(Y_train[0]), activation='softmax'))
model_mlp.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')
model_mlp.summary()

mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
model_mlp.save('food_model.h5')
mlp_train_pred = model_mlp.predict(X_train)
mlp_valid_pred = model_mlp.predict(X_valid)
