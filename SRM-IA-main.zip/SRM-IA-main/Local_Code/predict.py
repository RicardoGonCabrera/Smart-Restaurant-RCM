from keras.models import load_model
import numpy as np
import datetime
import json

def predict(date, local_event, num_reservados):
    date_time_obj = datetime.datetime.strptime(date, '%d-%m-%Y').date()
    month = date_time_obj.month
    day = date_time_obj.day
    weekday = date_time_obj.weekday()
    season = month % 12 // 3 + 1
    print(season)
    if local_event == 'No':
        local_event = 0
    else:
        local_event = 1
    customers_model = load_model('customers_model.h5')
    customer_flow = customers_model.predict(np.array([[month, day, weekday, local_event, season]]).astype(np.float32))[0][0]/1.5
    if customer_flow * 0.6 < num_reservados:
        customer_flow = customer_flow * 0.6 + num_reservados

    food_model = load_model('food_model.h5')
    with open('names.txt') as json_file:
        names = json.load(json_file)
    food_predictions = food_model.predict(np.array([[month, day, weekday, local_event]]).astype(np.float32))
    prediction = np.argmax(food_predictions)
    food = names[prediction]
    print(customer_flow,food)

predict("15-10-2022", 'No', 0)