import tensorflow as tf
import pandas as pd
import json
import numpy as np
from sklearn.model_selection import train_test_split
from keras.models import Sequential, Model, load_model
from keras.layers import Dense, Dropout
from keras.utils.np_utils import to_categorical
from sklearn.preprocessing import LabelEncoder


def prepare_data():
  with open('ss.json', 'r') as f:
    data = json.load(f)

  data = list(data.values())[0]
  df = []
  for i in data:
    for j in i['food_types']:
      df.append([i['date'], j, i['festive'],1])
  df=pd.DataFrame(df, columns=['Date', 'Item Name', 'Festive', 'Quantity'])


  df.loc[df['Festive'] == False, 'Festive'] = 0
  df.loc[df['Festive'] == True, 'Festive'] = 1


  df['Date'] = pd.to_datetime(df['Date']).dt.date
  df['Day'] = pd.to_datetime(df['Date']).dt.dayofweek
  df['Season'] = pd.to_datetime(df['Date']).dt.month % 12 // 3 + 1
  df['numDay'] = pd.to_datetime(df['Date']).dt.day
  df['numMonth'] = pd.to_datetime(df['Date']).dt.month

  return df


def train_customer_flow(df):
  df = df.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Season'], as_index=False)['Quantity'].sum()

  labels = df['Quantity']
  df = df.drop('Quantity', axis=1)
  x=np.asarray(df).astype(np.float32)
  y=np.asarray(labels).astype(np.float32)


  X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
  print('Train set shape', X_train.shape)
  print('Validation set shape', X_valid.shape)

  # MLP for Time Series Forecasting
  epochs = 400
  batch = 256
  lr = 0.0003
  adam = tf.keras.optimizers.Adam(lr)

  model_mlp = Sequential()
  model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
  model_mlp.add(Dense(1))
  model_mlp.compile(loss='mse', optimizer=adam)
  model_mlp.summary()

  mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
  model_mlp.save('customers_model.h5')



def train_food_prediction(train):
  df = train.groupby(['numMonth', 'numDay', 'Day', 'Festive', 'Item Name'], as_index=False)['Quantity'].sum()
  train = train.groupby(['numMonth', 'numDay', 'Day', 'Festive'], as_index=False)['Quantity'].sum()
  newdf = pd.DataFrame([])

  for j in train['numDay']:
    for i in train['numMonth'].unique():
      x = df.loc[(df.numMonth == i) & (df.numDay == j)]
      if not x.empty:
        x = x[x.Quantity == x.Quantity.max()].iloc[0]
        newdf = newdf.append(x)

  aa = sorted(newdf['Item Name'].unique().tolist())
  with open('names.txt', 'w') as outfile:
    json.dump(aa, outfile)
  newdf = newdf.drop('Quantity', 1)
  lb = LabelEncoder()
  labels = np.asarray(newdf['Item Name'])

  newdf = newdf.drop('Item Name', axis=1)
  x = np.asarray(newdf).astype(np.float32)
  y = to_categorical(lb.fit_transform(labels))

  X_train, X_valid, Y_train, Y_valid = train_test_split(x, y, test_size=0.3, random_state=0)
  print('Train set shape', X_train.shape)
  print('Validation set shape', X_valid.shape)

  # MLP
  epochs = 350
  batch = 256
  lr = 0.0003
  adam = tf.keras.optimizers.Adam(lr)

  model_mlp = Sequential()
  model_mlp.add(Dense(100, activation='relu', input_dim=X_train.shape[1]))
  model_mlp.add(Dropout(0.1))
  model_mlp.add(Dense(128, activation='relu'))
  model_mlp.add(Dropout(0.25))
  model_mlp.add(Dense(np.size(Y_train[0]), activation='softmax'))
  model_mlp.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')
  model_mlp.summary()

  mlp_history = model_mlp.fit(X_train, Y_train, validation_data=(X_valid, Y_valid), epochs=epochs, verbose=2)
  model_mlp.save('food_model.h5')


df=prepare_data()
print("AAAAAA")
train_food_prediction(df)
print("AAAAAA")

train_customer_flow(df)

