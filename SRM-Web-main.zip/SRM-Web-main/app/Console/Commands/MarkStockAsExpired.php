<?php

namespace App\Console\Commands;

use App\Models\Stock;
use Illuminate\Console\Command;

class MarkStockAsExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'stocks:expire';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Mark food as expired if their expiration date has passed';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            Stock::whereDate('expiration_date', '<=', \Carbon\Carbon::now()->toDateString())
                ->update(['expired' => true]);
        } catch (\Exception $exception) {
            return 1;
        }

        return 0;
    }
}
