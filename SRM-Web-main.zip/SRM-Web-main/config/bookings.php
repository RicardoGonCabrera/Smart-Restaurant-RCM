<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Bookings
    |--------------------------------------------------------------------------
    |
    | This file is for storing configuration of different values related with
    | bookings creation.
    |
    */

    'maximum_capacity' => env('MAXIMUM_CAPACITY', 50)

];
