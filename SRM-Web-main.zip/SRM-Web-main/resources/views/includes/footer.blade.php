<footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <a class="navbar-brand" href="#" style="font-size: 32px;">Smart Restaurant Manager</a> <br>
                <img src="{{asset('assets/images/logo-0.png')}}" style="max-width: 150px" alt="logo">
            </div>
        </div>
    </div>
</footer>
