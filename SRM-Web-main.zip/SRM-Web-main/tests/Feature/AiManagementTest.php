<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Recipe;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class AiManagementTest extends TestCase
{
    use RefreshDatabase;

    function test_ai_can_retrieve_retrain_data()
    {
        $orderStatus = OrderStatus::factory()->create();

        $bookingA = Booking::factory()->create(
            ['date' => '2022-05-21 21:30:00']
        );
        $recipesA = Recipe::factory()->count(3)->create(
            ['food_type' => 4]
        );
        $ordersA = Order::factory()->count(2)->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $bookingA->id
        ]);
        foreach ($ordersA as $order) {
            $order->recipes()->attach($recipesA, [
                'quantity' => 1,
                'price' => 19.99
            ]);
        }

        $bookingB = Booking::factory()->create(
            ['date' => '2022-05-20 21:30:00']
        );
        $recipesB = Recipe::factory()->count(3)->create(
            ['food_type' => 1]
        );
        $ordersB = Order::factory()->count(2)->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $bookingB->id
        ]);
        foreach ($ordersB as $order) {
            $order->recipes()->attach($recipesB, [
                'quantity' => 1,
                'price' => 19.99
            ]);
        }

        $bookingC = Booking::factory()->create(
            ['date' => '2022-05-19 21:30:00']
        );
        $recipesC = Recipe::factory()->count(3)->create(
            ['food_type' => 3]
        );
        $ordersC = Order::factory()->count(2)->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $bookingC->id
        ]);
        foreach ($ordersC as $order) {
            $order->recipes()->attach($recipesC, [
                'quantity' => 1,
                'price' => 19.99
            ]);
        }

        $response = $this->getJson(route('ai.data'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingA->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[4],
                        Recipe::FOOD_TYPES[4],
                        Recipe::FOOD_TYPES[4]
                    ],
                    'festive' => true
                ],
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingA->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[4],
                        Recipe::FOOD_TYPES[4],
                        Recipe::FOOD_TYPES[4]
                    ],
                    'festive' => true
                ],
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingB->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[1],
                        Recipe::FOOD_TYPES[1],
                        Recipe::FOOD_TYPES[1]
                    ],
                    'festive' => false
                ],
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingB->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[1],
                        Recipe::FOOD_TYPES[1],
                        Recipe::FOOD_TYPES[1]
                    ],
                    'festive' => false
                ],
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingC->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[3],
                        Recipe::FOOD_TYPES[3],
                        Recipe::FOOD_TYPES[3]
                    ],
                    'festive' => false
                ],
                [
                    'date' => \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $bookingC->date)->toDateString(),
                    'food_types' => [
                        Recipe::FOOD_TYPES[3],
                        Recipe::FOOD_TYPES[3],
                        Recipe::FOOD_TYPES[3]
                    ],
                    'festive' => false
                ]
            ]
        ]);
    }
}
