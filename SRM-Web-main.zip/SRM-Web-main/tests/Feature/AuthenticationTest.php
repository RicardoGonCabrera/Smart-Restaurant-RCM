<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    function test_guest_user_can_register()
    {
        $response = $this->postJson(route('register'), [
            'name' => 'Frank',
            'email' => 'frank@srm.com',
            'password' => 'password',
            'password_confirmation' => 'password'
        ]);

        $user = User::first();

        $response->assertCreated()->assertJson([
            'data' => [
                'type' => 'users',
                'id' => $user->id,
                'attributes' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'created_at' => $user->created_at->jsonSerialize(),
                    'updated_at' => $user->updated_at->jsonSerialize()
                ]
            ]
        ]);
        $this->assertDatabaseHas('users', ['email' => 'frank@srm.com']);
    }

    function test_guest_user_can_register_with_a_default_role_worker()
    {
        $response = $this->postJson(route('register'), [
            'name' => 'Frank',
            'email' => 'frank@srm.com',
            'password' => 'password',
            'password_confirmation' => 'password'
        ]);

        $user = User::first();

        $response->assertCreated()->assertJson([
            'data' => [
                'type' => 'users',
                'id' => $user->id,
                'attributes' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'created_at' => $user->created_at->jsonSerialize(),
                    'updated_at' => $user->updated_at->jsonSerialize()
                ]
            ]
        ]);
        $this->assertDatabaseHas('users', ['email' => 'frank@srm.com', 'role' => User::WORKER]);
    }

    function test_guest_user_can_register_with_a_role_administrator()
    {
        $response = $this->postJson(route('register'), [
            'name' => 'Frank',
            'email' => 'frank@srm.com',
            'password' => 'password',
            'password_confirmation' => 'password',
            'role' => User::ADMINISTRATOR
        ]);

        $user = User::first();

        $response->assertCreated()->assertJson([
            'data' => [
                'type' => 'users',
                'id' => $user->id,
                'attributes' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'created_at' => $user->created_at->jsonSerialize(),
                    'updated_at' => $user->updated_at->jsonSerialize()
                ]
            ]
        ]);
        $this->assertDatabaseHas('users', ['email' => 'frank@srm.com', 'role' => User::ADMINISTRATOR]);
    }

    function test_guest_user_can_register_with_a_role_worker()
    {
        $response = $this->postJson(route('register'), [
            'name' => 'Frank',
            'email' => 'frank@srm.com',
            'password' => 'password',
            'password_confirmation' => 'password',
            'role' => User::WORKER
        ]);

        $user = User::first();

        $response->assertCreated()->assertJson([
            'data' => [
                'type' => 'users',
                'id' => $user->id,
                'attributes' => [
                    'name' => $user->name,
                    'email' => $user->email,
                    'created_at' => $user->created_at->jsonSerialize(),
                    'updated_at' => $user->updated_at->jsonSerialize()
                ]
            ]
        ]);
        $this->assertDatabaseHas('users', ['email' => 'frank@srm.com', 'role' => User::WORKER]);
    }

    function test_guest_user_can_login()
    {
        $user = User::factory()->create([
            'email' => 'frank@srm.com',
            'password' => Hash::make('password')
        ]);

        $response = $this->postJson(route('login'), [
            'email' => 'frank@srm.com',
            'password' => 'password',
            'device_name' => 'SRM APP'
        ]);

        $response->assertOk();
    }

    function test_guest_user_can_not_login_with_wrong_password()
    {
        User::factory()->create([
            'email' => 'frank@srm.com',
            'password' => Hash::make('password')
        ]);

        $response = $this->postJson(route('login'), [
            'email' => 'frank@srm.com',
            'password' => 'not password',
            'device_name' => 'SRM APP'
        ]);

        $response->assertUnprocessable();
    }

    function test_authenticated_user_can_logout()
    {
        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('logout'));

        $response->assertOk();
    }

    function test_guest_user_can_not_logout()
    {
        $response = $this->postJson(route('logout'));

        $response->assertUnauthorized();
    }
}
