<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Recipe;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

class BookingManagementTest extends TestCase
{
    use RefreshDatabase;

    function test_authenticated_user_can_retrieve_all_bookings()
    {
        $booking = Booking::factory()->count(2)->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::bookings.index'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'bookings',
                    'id' => $booking[0]['id'],
                    'attributes' => [
                        'name' => $booking[0]['name'],
                        'email' => $booking[0]['email'],
                        'phone' => $booking[0]['phone'],
                        'date' => $booking[0]['date'],
                        'people' => $booking[0]['people'],
                        'table' => $booking[0]['table'],
                        'created_at' => $booking[0]['created_at']->jsonSerialize(),
                        'updated_at' => $booking[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'bookings',
                    'id' => $booking[1]['id'],
                    'attributes' => [
                        'name' => $booking[1]['name'],
                        'email' => $booking[1]['email'],
                        'phone' => $booking[1]['phone'],
                        'date' => $booking[1]['date'],
                        'people' => $booking[1]['people'],
                        'table' => $booking[1]['table'],
                        'created_at' => $booking[1]['created_at']->jsonSerialize(),
                        'updated_at' => $booking[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_bookings()
    {
        $response = $this->getJson(route('api::v1::bookings.index'));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_create_bookings()
    {
        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::bookings.store'), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertCreated();
        $this->assertDatabaseHas('bookings', [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);
    }

    function test_authenticated_user_can_not_create_bookings_if_maximum_capacity_is_reached()
    {
        Booking::factory()->count(5)->create([
            'date' => '2022-04-29 19:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(4)->create([
            'date' => '2022-04-29 23:30:00',
            'people' => 5
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::bookings.store'), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 6,
            'table' => 'foo table'
        ]);

        $response->assertUnprocessable();
    }

    function test_guest_user_can_not_create_bookings()
    {
        $response = $this->postJson(route('api::v1::bookings.store'), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_single_booking()
    {
        $booking = Booking::factory()->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::bookings.show', ['booking' => $booking]));

        $response->assertOk()->assertJson([
            'data' => [
                'type' => 'bookings',
                'id' => $booking->id,
                'attributes' => [
                    'name' => $booking->name,
                    'email' => $booking->email,
                    'phone' => $booking->phone,
                    'date' => $booking->date,
                    'people' => $booking->people,
                    'table' => $booking->table,
                    'created_at' => $booking->created_at->jsonSerialize(),
                    'updated_at' => $booking->updated_at->jsonSerialize()
                ]
            ]
        ], Response::HTTP_OK);
    }

    function test_guest_user_can_not_retrieve_single_booking()
    {
        $booking = Booking::factory()->create();

        $response = $this->getJson(route('api::v1::bookings.show', ['booking' => $booking]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_edit_bookings()
    {
        $booking = Booking::factory()->create([
            'people' => 20
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::bookings.update', ['booking' => $booking]), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertNoContent();
        $this->assertEquals('foo', $booking->refresh()->name);
        $this->assertEquals('foo@foo.com', $booking->refresh()->email);
        $this->assertEquals('+34 111 111 111', $booking->refresh()->phone);
        $this->assertEquals('2022-04-29 21:30:00', $booking->refresh()->date);
        $this->assertEquals(2, $booking->refresh()->people);
        $this->assertEquals('foo table', $booking->refresh()->table);
    }

    function test_authenticated_user_can_edit_bookings_with_the_same_date()
    {
        $booking = Booking::factory()->create([
            'date' => '2022-04-29 21:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(5)->create([
            'date' => '2022-04-29 20:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(4)->create([
            'date' => '2022-04-29 22:30:00',
            'people' => 5
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::bookings.update', ['booking' => $booking]), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertNoContent();
        $this->assertEquals('foo', $booking->refresh()->name);
        $this->assertEquals('foo@foo.com', $booking->refresh()->email);
        $this->assertEquals('+34 111 111 111', $booking->refresh()->phone);
        $this->assertEquals('2022-04-29 21:30:00', $booking->refresh()->date);
        $this->assertEquals(2, $booking->refresh()->people);
        $this->assertEquals('foo table', $booking->refresh()->table);
    }

    function test_authenticated_user_can_not_edit_bookings_if_maximum_capacity_is_reached_in_new_date()
    {
        $booking = Booking::factory()->create([
            'date' => '2022-04-29 14:30:00'
        ]);

        Booking::factory()->count(5)->create([
            'date' => '2022-04-29 20:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(5)->create([
            'date' => '2022-04-29 22:30:00',
            'people' => 5
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::bookings.update', ['booking' => $booking]), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertUnprocessable();
    }

    function test_authenticated_user_can_not_edit_bookings_if_maximum_capacity_is_reached_in_the_same_date()
    {
        $booking = Booking::factory()->create([
            'date' => '2022-04-29 21:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(5)->create([
            'date' => '2022-04-29 20:30:00',
            'people' => 5
        ]);

        Booking::factory()->count(4)->create([
            'date' => '2022-04-29 22:30:00',
            'people' => 5
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::bookings.update', ['booking' => $booking]), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 6,
            'table' => 'foo table'
        ]);

        $response->assertUnprocessable();
    }

    function test_guest_user_can_not_edit_bookings()
    {
        $booking = Booking::factory()->create();

        $response = $this->putJson(route('api::v1::bookings.update', ['booking' => $booking]), [
            'name' => 'foo',
            'email' => 'foo@foo.com',
            'phone' => '+34 111 111 111',
            'date' => '2022-04-29 21:30:00',
            'people' => 2,
            'table' => 'foo table'
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_delete_bookings()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->deleteJson(route('api::v1::bookings.destroy', ['booking' => $booking]));

        $response->assertStatus(Response::HTTP_CONFLICT);

        $order->recipes()->detach();
        $booking->orders()->delete();

        $response = $this->deleteJson(route('api::v1::bookings.destroy', ['booking' => $booking]));

        $response->assertNoContent();
        $this->assertDatabaseMissing('bookings', [
            'id' => $booking->id
        ]);
    }

    function test_guest_user_can_not_delete_bookings()
    {
        $booking = Booking::factory()->create();

        $response = $this->deleteJson(route('api::v1::bookings.destroy', ['booking' => $booking]));

        $response->assertUnauthorized();
    }
}
