<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Food;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Recipe;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

class FoodManagementTest extends TestCase
{
    use RefreshDatabase;

    function test_authenticated_user_can_retrieve_all_food()
    {
        $food = Food::factory()->count(2)->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'food_id' => $food[0]->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food[0]->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::food.index'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'food',
                    'id' => $food[0]['id'],
                    'attributes' => [
                        'name' => $food[0]['name'],
                        'units' => $food[0]['units'],
                        'type' => $food[0]['type'],
                        'stock' => ($nonExpiredStocks[0]->quantity + $nonExpiredStocks[1]->quantity),
                        'created_at' => $food[0]['created_at']->jsonSerialize(),
                        'updated_at' => $food[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'food',
                    'id' => $food[1]['id'],
                    'attributes' => [
                        'name' => $food[1]['name'],
                        'units' => $food[1]['units'],
                        'type' => $food[1]['type'],
                        'stock' => 0,
                        'created_at' => $food[1]['created_at']->jsonSerialize(),
                        'updated_at' => $food[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_food()
    {
        $response = $this->getJson(route('api::v1::food.index'));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_create_food()
    {
        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::food.store'), [
            'name' => 'foo',
            'units' => 'kg',
            'type' => 'foo type'
        ]);

        $response->assertCreated();
        $this->assertDatabaseHas('food', [
            'name' => 'foo',
            'units' => 'kg',
            'type' => 'foo type'
        ]);
    }

    function test_guest_user_can_not_create_food()
    {
        $response = $this->postJson(route('api::v1::food.store'), [
            'name' => 'foo',
            'units' => 'kg',
            'type' => 'foo type'
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_single_food()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::food.show', ['food' => $food]));

        $response->assertOk()->assertJson([
            'data' => [
                'type' => 'food',
                'id' => $food->id,
                'attributes' => [
                    'name' => $food->name,
                    'units' => $food->units,
                    'type' => $food->type,
                    'stock' => ($nonExpiredStocks[0]->quantity + $nonExpiredStocks[1]->quantity),
                    'created_at' => $food->created_at->jsonSerialize(),
                    'updated_at' => $food->updated_at->jsonSerialize()
                ]
            ]
        ], Response::HTTP_OK);
    }

    function test_guest_user_can_not_retrieve_single_food()
    {
        $food = Food::factory()->create();

        $response = $this->getJson(route('api::v1::food.show', ['food' => $food]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_edit_food()
    {
        $food = Food::factory()->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::food.update', ['food' => $food]), [
            'name' => 'foo',
            'units' => 'kg',
            'type' => 'foo type'
        ]);

        $response->assertNoContent();
        $this->assertEquals('foo', $food->refresh()->name);
        $this->assertEquals('kg', $food->refresh()->units);
        $this->assertEquals('foo type', $food->refresh()->type);
    }

    function test_guest_user_can_not_edit_food()
    {
        $food = Food::factory()->create();

        $response = $this->putJson(route('api::v1::food.update', ['food' => $food]), [
            'name' => 'foo',
            'units' => 'kg',
            'type' => 'foo type'
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_delete_food()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );
        $recipes = Recipe::factory()->count(2)->create();
        foreach ($recipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 450.50]);
        }
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->deleteJson(route('api::v1::food.destroy', ['food' => $food]));

        $response->assertStatus(Response::HTTP_CONFLICT);

        $food->recipes()->detach();

        $response = $this->deleteJson(route('api::v1::food.destroy', ['food' => $food]));

        $response->assertStatus(Response::HTTP_CONFLICT);

        $food->stocks()->delete();

        $response = $this->deleteJson(route('api::v1::food.destroy', ['food' => $food]));

        $response->assertNoContent();
        $this->assertDatabaseMissing('food', [
            'id' => $food->id
        ]);
    }

    function test_guest_user_can_not_delete_food()
    {
        $food = Food::factory()->create();

        $response = $this->deleteJson(route('api::v1::food.destroy', ['food' => $food]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_stocks_of_food()
    {
        $food = Food::factory()->create();
        $stocks = Stock::factory()->count(2)->create(
            ['food_id' => $food->id]
        );

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::food.stocks', ['food' => $food]));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'stocks',
                    'id' => $stocks[0]['id'],
                    'attributes' => [
                        'quantity' => $stocks[0]['quantity'],
                        'expiration_date' => $stocks[0]['expiration_date'],
                        'expired' => $stocks[0]['expired'],
                        'food_id' => $stocks[0]['food_id'],
                        'created_at' => $stocks[0]['created_at']->jsonSerialize(),
                        'updated_at' => $stocks[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'stocks',
                    'id' => $stocks[1]['id'],
                    'attributes' => [
                        'quantity' => $stocks[1]['quantity'],
                        'expiration_date' => $stocks[1]['expiration_date'],
                        'expired' => $stocks[1]['expired'],
                        'food_id' => $stocks[1]['food_id'],
                        'created_at' => $stocks[1]['created_at']->jsonSerialize(),
                        'updated_at' => $stocks[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_stocks_of_food()
    {
        $food = Food::factory()->create();
        $stocks = Stock::factory()->count(2)->create(
            ['food_id' => $food->id]
        );

        $response = $this->getJson(route('api::v1::food.stocks', ['food' => $food]));

        $response->assertUnauthorized();
    }
}
