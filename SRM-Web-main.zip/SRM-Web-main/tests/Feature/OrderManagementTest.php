<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Food;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Recipe;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class OrderManagementTest extends TestCase
{
    use RefreshDatabase;

    function test_authenticated_user_can_retrieve_all_orders()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $orders = Order::factory()->count(2)->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        foreach ($orders as $order) {
            $order->recipes()->attach($recipes, [
                'quantity' => 1,
                'price' => 19.99
            ]);
        }

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.index'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $orders[0]->id,
                    'attributes' => [
                        'order_status_id' => $orders[0]->order_status_id,
                        'booking_id' => $orders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $orderStatus->id,
                            'attributes' => [
                                'status' => $orderStatus->status,
                                'created_at' => $orderStatus->created_at->jsonSerialize(),
                                'updated_at' => $orderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [
                            [
                                'order_id' => $orders[0]->recipes[0]->pivot->order_id,
                                'recipe_id' => $orders[0]->recipes[0]->pivot->recipe_id,
                                'recipe_name' => $orders[0]->recipes[0]->name,
                                'quantity' => $orders[0]->recipes[0]->pivot->quantity,
                                'price' => $orders[0]->recipes[0]->pivot->price,
                                'created_at' => $orders[0]->recipes[0]->pivot->created_at->jsonSerialize(),
                                'updated_at' => $orders[0]->recipes[0]->pivot->updated_at->jsonSerialize()
                            ],
                            [
                                'order_id' => $orders[0]->recipes[1]->pivot->order_id,
                                'recipe_id' => $orders[0]->recipes[1]->pivot->recipe_id,
                                'recipe_name' => $orders[0]->recipes[1]->name,
                                'quantity' => $orders[0]->recipes[1]->pivot->quantity,
                                'price' => $orders[0]->recipes[1]->pivot->price,
                                'created_at' => $orders[0]->recipes[1]->pivot->created_at->jsonSerialize(),
                                'updated_at' => $orders[0]->recipes[1]->pivot->updated_at->jsonSerialize()
                            ]
                        ],
                        'created_at' => $orders[0]->created_at->jsonSerialize(),
                        'updated_at' => $orders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $orders[1]->id,
                    'attributes' => [
                        'order_status_id' => $orders[1]->order_status_id,
                        'booking_id' => $orders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $orderStatus->id,
                            'attributes' => [
                                'status' => $orderStatus->status,
                                'created_at' => $orderStatus->created_at->jsonSerialize(),
                                'updated_at' => $orderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [
                            [
                                'order_id' => $orders[1]->recipes[0]->pivot->order_id,
                                'recipe_id' => $orders[1]->recipes[0]->pivot->recipe_id,
                                'recipe_name' => $orders[1]->recipes[0]->name,
                                'quantity' => $orders[1]->recipes[0]->pivot->quantity,
                                'price' => $orders[1]->recipes[0]->pivot->price,
                                'created_at' => $orders[1]->recipes[0]->pivot->created_at->jsonSerialize(),
                                'updated_at' => $orders[1]->recipes[0]->pivot->updated_at->jsonSerialize()
                            ],
                            [
                                'order_id' => $orders[1]->recipes[1]->pivot->order_id,
                                'recipe_id' => $orders[1]->recipes[1]->pivot->recipe_id,
                                'recipe_name' => $orders[1]->recipes[1]->name,
                                'quantity' => $orders[1]->recipes[1]->pivot->quantity,
                                'price' => $orders[1]->recipes[1]->pivot->price,
                                'created_at' => $orders[1]->recipes[1]->pivot->created_at->jsonSerialize(),
                                'updated_at' => $orders[1]->recipes[1]->pivot->updated_at->jsonSerialize()
                            ]
                        ],
                        'created_at' => $orders[1]->created_at->jsonSerialize(),
                        'updated_at' => $orders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_orders()
    {
        $response = $this->getJson(route('api::v1::orders.index'));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_create_orders()
    {
        $this->seed();

        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $orderStatus = OrderStatus::waiting();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();
        foreach ($recipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::orders.store'), [
            'booking_id' => $booking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => $recipes[0]->price * 2
                ],
                [
                    'recipe_id' => $recipes[1]->id,
                    'quantity' => 2,
                    'price' => $recipes[1]->price * 2
                ],
                [
                    'recipe_id' => $recipes[2]->id,
                    'quantity' => 1,
                    'price' => 5.49
                ],
            ]
        ]);

        $response->assertCreated();
        $this->assertDatabaseHas('orders', [
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $this->assertDatabaseHas('order_recipe', [
            'order_id' => 1,
            'recipe_id' => $recipes[0]->id,
            'quantity' => 2,
            'price' => $recipes[0]->price * 2
        ]);
        $this->assertDatabaseHas('order_recipe', [
            'order_id' => 1,
            'recipe_id' => $recipes[1]->id,
            'quantity' => 2,
            'price' => $recipes[1]->price * 2
        ]);
        $this->assertDatabaseHas('order_recipe', [
            'order_id' => 1,
            'recipe_id' => $recipes[2]->id,
            'quantity' => 1,
            'price' => 5.49
        ]);
    }

    function test_authenticated_user_can_not_create_orders_without_stock()
    {
        $this->seed();

        $orderStatus = OrderStatus::waiting();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::orders.store'), [
            'booking_id' => $booking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => $recipes[0]->price * 2
                ],
                [
                    'recipe_id' => $recipes[1]->id,
                    'quantity' => 2,
                    'price' => $recipes[1]->price * 2
                ],
                [
                    'recipe_id' => $recipes[2]->id,
                    'quantity' => 1,
                    'price' => 5.49
                ],
            ]
        ]);

        $response->assertUnprocessable();
    }

    function test_guest_user_can_not_create_orders()
    {
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();

        $response = $this->postJson(route('api::v1::orders.store'), [
            'booking_id' => $booking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => $recipes[0]->price * 2
                ],
                [
                    'recipe_id' => $recipes[1]->id,
                    'quantity' => 2,
                    'price' => $recipes[1]->price * 2
                ],
                [
                    'recipe_id' => $recipes[2]->id,
                    'quantity' => 1,
                    'price' => 5.49
                ],
            ]
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_single_order()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.show', ['order' => $order]));

        $response->assertOk()->assertJson([
            'data' => [
                'type' => 'orders',
                'id' => $order->id,
                'attributes' => [
                    'order_status_id' => $order->order_status_id,
                    'booking_id' => $order->booking_id,
                    'status' => [
                        'type' => 'order_statuses',
                        'id' => $orderStatus->id,
                        'attributes' => [
                            'status' => $orderStatus->status,
                            'created_at' => $orderStatus->created_at->jsonSerialize(),
                            'updated_at' => $orderStatus->updated_at->jsonSerialize()
                        ]
                    ],
                    'booking' => [
                        'type' => 'bookings',
                        'id' => $booking->id,
                        'attributes' => [
                            'name' => $booking->name,
                            'email' => $booking->email,
                            'phone' => $booking->phone,
                            'date' => $booking->date,
                            'people' => $booking->people,
                            'table' => $booking->table,
                            'created_at' => $booking->created_at->jsonSerialize(),
                            'updated_at' => $booking->updated_at->jsonSerialize()
                        ]
                    ],
                    'recipes' => [
                        [
                            'order_id' => $order->recipes[0]->pivot->order_id,
                            'recipe_id' => $order->recipes[0]->pivot->recipe_id,
                            'recipe_name' => $order->recipes[0]->name,
                            'quantity' => $order->recipes[0]->pivot->quantity,
                            'price' => $order->recipes[0]->pivot->price,
                            'created_at' => $order->recipes[0]->pivot->created_at->jsonSerialize(),
                            'updated_at' => $order->recipes[0]->pivot->updated_at->jsonSerialize()
                        ],
                        [
                            'order_id' => $order->recipes[1]->pivot->order_id,
                            'recipe_id' => $order->recipes[1]->pivot->recipe_id,
                            'recipe_name' => $order->recipes[1]->name,
                            'quantity' => $order->recipes[1]->pivot->quantity,
                            'price' => $order->recipes[1]->pivot->price,
                            'created_at' => $order->recipes[1]->pivot->created_at->jsonSerialize(),
                            'updated_at' => $order->recipes[1]->pivot->updated_at->jsonSerialize()
                        ]
                    ],
                    'created_at' => $order->created_at->jsonSerialize(),
                    'updated_at' => $order->updated_at->jsonSerialize()
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_single_order()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $response = $this->getJson(route('api::v1::orders.show', ['order' => $order]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_edit_orders_without_order_status_id()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();
        foreach ($recipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $newBooking = Booking::factory()->create();
        $newRecipes = Recipe::factory()->count(2)->create();
        foreach ($newRecipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::orders.update', ['order' => $order]), [
            'booking_id' => $newBooking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => 38.98
                ],
                [
                    'recipe_id' => $newRecipes[0]->id,
                    'quantity' => 2,
                    'price' => 25.55
                ],
                [
                    'recipe_id' => $newRecipes[1]->id,
                    'quantity' => 1,
                    'price' => 9.50
                ]

            ]
        ]);

        $response->assertNoContent();

        $this->assertEquals($orderStatus->id, $order->refresh()->order_status_id);
        $this->assertEquals($newBooking->id, $order->refresh()->booking_id);

        $recipeIds = $order->refresh()->recipes->map(function ($recipe, $key) {
            return $recipe->id;
        });

        $this->assertFalse($recipeIds->contains($recipes[1]->id));
        $this->assertTrue($recipeIds->contains($recipes[0]->id));
        $this->assertTrue($recipeIds->contains($newRecipes[0]->id));
        $this->assertTrue($recipeIds->contains($newRecipes[1]->id));
    }

    function test_authenticated_user_can_edit_orders_with_order_status_id()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();
        foreach ($recipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $newOrderStatus = OrderStatus::factory()->create();
        $newBooking = Booking::factory()->create();
        $newRecipes = Recipe::factory()->count(2)->create();
        foreach ($newRecipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::orders.update', ['order' => $order]), [
            'order_status_id' => $newOrderStatus->id,
            'booking_id' => $newBooking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => 38.98
                ],
                [
                    'recipe_id' => $newRecipes[0]->id,
                    'quantity' => 2,
                    'price' => 25.55
                ],
                [
                    'recipe_id' => $newRecipes[1]->id,
                    'quantity' => 1,
                    'price' => 9.50
                ]

            ]
        ]);

        $response->assertNoContent();

        $this->assertEquals($newOrderStatus->id, $order->refresh()->order_status_id);
        $this->assertEquals($newBooking->id, $order->refresh()->booking_id);

        $recipeIds = $order->refresh()->recipes->map(function ($recipe, $key) {
            return $recipe->id;
        });

        $this->assertFalse($recipeIds->contains($recipes[1]->id));
        $this->assertTrue($recipeIds->contains($recipes[0]->id));
        $this->assertTrue($recipeIds->contains($newRecipes[0]->id));
        $this->assertTrue($recipeIds->contains($newRecipes[1]->id));
    }

    function test_authenticated_user_can_not_edit_orders_with_recipes_without_stock()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(3)->create();
        foreach ($recipes as $recipe) {
            $recipe->food()->attach($food, ['quantity' => 20]);
        }
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $newOrderStatus = OrderStatus::factory()->create();
        $newBooking = Booking::factory()->create();
        $newRecipes = Recipe::factory()->count(2)->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::orders.update', ['order' => $order]), [
            'order_status_id' => $newOrderStatus->id,
            'booking_id' => $newBooking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => 38.98
                ],
                [
                    'recipe_id' => $newRecipes[0]->id,
                    'quantity' => 2,
                    'price' => 25.55
                ],
                [
                    'recipe_id' => $newRecipes[1]->id,
                    'quantity' => 1,
                    'price' => 9.50
                ]

            ]
        ]);

        $response->assertUnprocessable();
    }

    function test_guest_user_can_not_edit_recipes()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $newBooking = Booking::factory()->create();
        $newRecipes = Recipe::factory()->count(2)->create();

        $response = $this->putJson(route('api::v1::orders.update', ['order' => $order]), [
            'booking_id' => $newBooking->id,
            'recipes' => [
                [
                    'recipe_id' => $recipes[0]->id,
                    'quantity' => 2,
                    'price' => 38.98
                ],
                [
                    'recipe_id' => $newRecipes[0]->id,
                    'quantity' => 2,
                    'price' => 25.55
                ],
                [
                    'recipe_id' => $newRecipes[1]->id,
                    'quantity' => 1,
                    'price' => 9.50
                ]

            ]
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_delete_orders()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->deleteJson(route('api::v1::orders.destroy', ['order' => $order]));

        $response->assertNoContent();
        $this->assertDatabaseMissing('orders', [
            'id' => $order->id
        ]);
        $this->assertDatabaseMissing('order_recipe', [
            'order_id' => $order->id
        ]);
    }

    function test_guest_user_can_not_delete_orders()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $recipes = Recipe::factory()->count(2)->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipes, [
            'quantity' => 1,
            'price' => 19.99
        ]);

        $response = $this->deleteJson(route('api::v1::orders.destroy', ['order' => $order]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_all_waiting_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $waitingOrderStatus = OrderStatus::waiting();
        $waitingOrders = Order::factory()->count(2)->create([
            'order_status_id' => $waitingOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.waiting'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $waitingOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $waitingOrders[0]->order_status_id,
                        'booking_id' => $waitingOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $waitingOrderStatus->id,
                            'attributes' => [
                                'status' => $waitingOrderStatus->status,
                                'created_at' => $waitingOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $waitingOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $waitingOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $waitingOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $waitingOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $waitingOrders[1]->order_status_id,
                        'booking_id' => $waitingOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $waitingOrderStatus->id,
                            'attributes' => [
                                'status' => $waitingOrderStatus->status,
                                'created_at' => $waitingOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $waitingOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $waitingOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $waitingOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_authenticated_user_can_retrieve_all_confirmed_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $confirmedOrderStatus = OrderStatus::confirmed();
        $confirmedOrders = Order::factory()->count(2)->create([
            'order_status_id' => $confirmedOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.confirmed'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $confirmedOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $confirmedOrders[0]->order_status_id,
                        'booking_id' => $confirmedOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $confirmedOrderStatus->id,
                            'attributes' => [
                                'status' => $confirmedOrderStatus->status,
                                'created_at' => $confirmedOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $confirmedOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $confirmedOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $confirmedOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $confirmedOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $confirmedOrders[1]->order_status_id,
                        'booking_id' => $confirmedOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $confirmedOrderStatus->id,
                            'attributes' => [
                                'status' => $confirmedOrderStatus->status,
                                'created_at' => $confirmedOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $confirmedOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $confirmedOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $confirmedOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_authenticated_user_can_retrieve_all_cancelled_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $cancelledOrderStatus = OrderStatus::cancelled();
        $cancelledOrders = Order::factory()->count(2)->create([
            'order_status_id' => $cancelledOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.cancelled'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $cancelledOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $cancelledOrders[0]->order_status_id,
                        'booking_id' => $cancelledOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $cancelledOrderStatus->id,
                            'attributes' => [
                                'status' => $cancelledOrderStatus->status,
                                'created_at' => $cancelledOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $cancelledOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $cancelledOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $cancelledOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $cancelledOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $cancelledOrders[1]->order_status_id,
                        'booking_id' => $cancelledOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $cancelledOrderStatus->id,
                            'attributes' => [
                                'status' => $cancelledOrderStatus->status,
                                'created_at' => $cancelledOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $cancelledOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $cancelledOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $cancelledOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_authenticated_user_can_retrieve_all_in_process_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $inProcessOrderStatus = OrderStatus::inProcess();
        $inProcessOrders = Order::factory()->count(2)->create([
            'order_status_id' => $inProcessOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.in-process'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $inProcessOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $inProcessOrders[0]->order_status_id,
                        'booking_id' => $inProcessOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $inProcessOrderStatus->id,
                            'attributes' => [
                                'status' => $inProcessOrderStatus->status,
                                'created_at' => $inProcessOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $inProcessOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $inProcessOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $inProcessOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $inProcessOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $inProcessOrders[1]->order_status_id,
                        'booking_id' => $inProcessOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $inProcessOrderStatus->id,
                            'attributes' => [
                                'status' => $inProcessOrderStatus->status,
                                'created_at' => $inProcessOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $inProcessOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $inProcessOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $inProcessOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_authenticated_user_can_retrieve_all_delivered_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $deliveredOrderStatus = OrderStatus::delivered();
        $deliveredOrders = Order::factory()->count(2)->create([
            'order_status_id' => $deliveredOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.delivered'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $deliveredOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $deliveredOrders[0]->order_status_id,
                        'booking_id' => $deliveredOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $deliveredOrderStatus->id,
                            'attributes' => [
                                'status' => $deliveredOrderStatus->status,
                                'created_at' => $deliveredOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $deliveredOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $deliveredOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $deliveredOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $deliveredOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $deliveredOrders[1]->order_status_id,
                        'booking_id' => $deliveredOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $deliveredOrderStatus->id,
                            'attributes' => [
                                'status' => $deliveredOrderStatus->status,
                                'created_at' => $deliveredOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $deliveredOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $deliveredOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $deliveredOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_authenticated_user_can_retrieve_all_paid_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $paidOrderStatus = OrderStatus::paid();
        $paidOrders = Order::factory()->count(2)->create([
            'order_status_id' => $paidOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::orders.paid'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'orders',
                    'id' => $paidOrders[0]->id,
                    'attributes' => [
                        'order_status_id' => $paidOrders[0]->order_status_id,
                        'booking_id' => $paidOrders[0]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $paidOrderStatus->id,
                            'attributes' => [
                                'status' => $paidOrderStatus->status,
                                'created_at' => $paidOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $paidOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $paidOrders[0]->created_at->jsonSerialize(),
                        'updated_at' => $paidOrders[0]->updated_at->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'orders',
                    'id' => $paidOrders[1]->id,
                    'attributes' => [
                        'order_status_id' => $paidOrders[1]->order_status_id,
                        'booking_id' => $paidOrders[1]->booking_id,
                        'status' => [
                            'type' => 'order_statuses',
                            'id' => $paidOrderStatus->id,
                            'attributes' => [
                                'status' => $paidOrderStatus->status,
                                'created_at' => $paidOrderStatus->created_at->jsonSerialize(),
                                'updated_at' => $paidOrderStatus->updated_at->jsonSerialize()
                            ]
                        ],
                        'booking' => [
                            'type' => 'bookings',
                            'id' => $booking->id,
                            'attributes' => [
                                'name' => $booking->name,
                                'email' => $booking->email,
                                'phone' => $booking->phone,
                                'date' => $booking->date,
                                'people' => $booking->people,
                                'table' => $booking->table,
                                'created_at' => $booking->created_at->jsonSerialize(),
                                'updated_at' => $booking->updated_at->jsonSerialize()
                            ]
                        ],
                        'recipes' => [],
                        'created_at' => $paidOrders[1]->created_at->jsonSerialize(),
                        'updated_at' => $paidOrders[1]->updated_at->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_waiting_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $waitingOrderStatus = OrderStatus::waiting();
        $waitingOrders = Order::factory()->count(2)->create([
            'order_status_id' => $waitingOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.waiting'));

        $response->assertUnauthorized();
    }

    function test_guest_user_can_not_retrieve_all_confirmed_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $confirmedOrderStatus = OrderStatus::confirmed();
        $confirmedOrders = Order::factory()->count(2)->create([
            'order_status_id' => $confirmedOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.confirmed'));

        $response->assertUnauthorized();
    }

    function test_guest_user_can_not_retrieve_all_cancelled_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $cancelledOrderStatus = OrderStatus::cancelled();
        $cancelledOrders = Order::factory()->count(2)->create([
            'order_status_id' => $cancelledOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.cancelled'));

        $response->assertUnauthorized();
    }

    function test_guest_user_can_not_retrieve_all_in_process_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $inProcessOrderStatus = OrderStatus::inProcess();
        $inProcessOrders = Order::factory()->count(2)->create([
            'order_status_id' => $inProcessOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.in-process'));

        $response->assertUnauthorized();
    }

    function test_guest_user_can_not_retrieve_all_delivered_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $deliveredOrderStatus = OrderStatus::delivered();
        $deliveredOrders = Order::factory()->count(2)->create([
            'order_status_id' => $deliveredOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.delivered'));

        $response->assertUnauthorized();
    }

    function test_guest_user_can_not_retrieve_all_paid_orders()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $paidOrderStatus = OrderStatus::paid();
        $paidOrders = Order::factory()->count(2)->create([
            'order_status_id' => $paidOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $response = $this->getJson(route('api::v1::orders.paid'));

        $response->assertUnauthorized();
    }
}
