<?php

namespace Tests\Feature;

use App\Models\Food;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

class StockManagementTest extends TestCase
{
    use RefreshDatabase;

    function test_authenticated_user_can_retrieve_all_stocks()
    {
        $food = Food::factory()->create();
        $stocks = Stock::factory()->count(2)->create(
            ['food_id' => $food->id]
        );

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::stocks.index'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'stocks',
                    'id' => $stocks[0]['id'],
                    'attributes' => [
                        'quantity' => $stocks[0]['quantity'],
                        'expiration_date' => $stocks[0]['expiration_date'],
                        'expired' => $stocks[0]['expired'],
                        'food_id' => $stocks[0]['food_id'],
                        'created_at' => $stocks[0]['created_at']->jsonSerialize(),
                        'updated_at' => $stocks[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'stocks',
                    'id' => $stocks[1]['id'],
                    'attributes' => [
                        'quantity' => $stocks[1]['quantity'],
                        'expiration_date' => $stocks[1]['expiration_date'],
                        'expired' => $stocks[1]['expired'],
                        'food_id' => $stocks[1]['food_id'],
                        'created_at' => $stocks[1]['created_at']->jsonSerialize(),
                        'updated_at' => $stocks[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_stocks()
    {
        $response = $this->getJson(route('api::v1::stocks.index'));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_create_stocks()
    {
        $food = Food::factory()->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->postJson(route('api::v1::stocks.store'), [
            'quantity' => 350.0,
            'expiration_date' => '2022-11-22 11:20:30',
            'food_id' => $food->id
        ]);

        $response->assertCreated();
        $this->assertDatabaseHas('stocks', [
            'quantity' => 350.0,
            'expiration_date' => '2022-11-22 11:20:30',
            'food_id' => $food->id
        ]);
    }

    function test_guest_user_can_not_create_stocks()
    {
        $food = Food::factory()->create();

        $response = $this->postJson(route('api::v1::stocks.store'), [
            'quantity' => 350.0,
            'expiration_date' => '2022-11-22 11:20:30',
            'food_id' => $food->id
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_single_stock()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::stocks.show', ['stock' => $stock]));

        $response->assertOk()->assertJson([
            'data' => [
                'type' => 'stocks',
                'id' => $stock->id,
                'attributes' => [
                    'quantity' => $stock->quantity,
                    'expiration_date' => $stock->expiration_date,
                    'expired' => $stock->expired,
                    'food_id' => $stock->food_id,
                    'created_at' => $stock->created_at->jsonSerialize(),
                    'updated_at' => $stock->updated_at->jsonSerialize()
                ]
            ]
        ], Response::HTTP_OK);
    }

    function test_guest_user_can_not_retrieve_single_stock()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );

        $response = $this->getJson(route('api::v1::stocks.show', ['stock' => $stock]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_edit_stocks()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );
        $newFood = Food::factory()->create();

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->putJson(route('api::v1::stocks.update', ['stock' => $stock]), [
            'quantity' => 350.0,
            'expiration_date' => '2022-11-22 11:20:30',
            'expired' => true,
            'food_id' => $newFood->id
        ]);

        $response->assertNoContent();
        $this->assertEquals(350.0, $stock->refresh()->quantity);
        $this->assertEquals('2022-11-22 11:20:30', $stock->refresh()->expiration_date);
        $this->assertEquals(true, $stock->refresh()->expired);
        $this->assertEquals($newFood->id, $stock->refresh()->food_id);
    }

    function test_guest_user_can_not_edit_stocks()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );
        $newFood = Food::factory()->create();

        $response = $this->putJson(route('api::v1::stocks.update', ['stock' => $stock]), [
            'quantity' => 350.0,
            'expiration_date' => '2022-11-22 11:20:30',
            'food_id' => $newFood->id
        ]);

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_delete_stocks()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->deleteJson(route('api::v1::stocks.destroy', ['stock' => $stock]));

        $response->assertNoContent();
        $this->assertDatabaseMissing('stocks', [
            'id' => $stock->id
        ]);
    }

    function test_guest_user_can_not_delete_stocks()
    {
        $food = Food::factory()->create();
        $stock = Stock::factory()->create(
            ['food_id' => $food->id]
        );

        $response = $this->deleteJson(route('api::v1::stocks.destroy', ['stock' => $stock]));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_all_expired_stocks()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::stocks.expired'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'stocks',
                    'id' => $expiredStocks[0]['id'],
                    'attributes' => [
                        'quantity' => $expiredStocks[0]['quantity'],
                        'expiration_date' => $expiredStocks[0]['expiration_date'],
                        'expired' => $expiredStocks[0]['expired'],
                        'food_id' => $expiredStocks[0]['food_id'],
                        'created_at' => $expiredStocks[0]['created_at']->jsonSerialize(),
                        'updated_at' => $expiredStocks[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'stocks',
                    'id' => $expiredStocks[1]['id'],
                    'attributes' => [
                        'quantity' => $expiredStocks[1]['quantity'],
                        'expiration_date' => $expiredStocks[1]['expiration_date'],
                        'expired' => $expiredStocks[1]['expired'],
                        'food_id' => $expiredStocks[1]['food_id'],
                        'created_at' => $expiredStocks[1]['created_at']->jsonSerialize(),
                        'updated_at' => $expiredStocks[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_expired_stocks()
    {
        $response = $this->getJson(route('api::v1::stocks.expired'));

        $response->assertUnauthorized();
    }

    function test_authenticated_user_can_retrieve_all_non_expired_stocks()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        Sanctum::actingAs(
            User::factory()->create()
        );

        $response = $this->getJson(route('api::v1::stocks.nonExpired'));

        $response->assertOk()->assertJson([
            'data' => [
                [
                    'type' => 'stocks',
                    'id' => $nonExpiredStocks[0]['id'],
                    'attributes' => [
                        'quantity' => $nonExpiredStocks[0]['quantity'],
                        'expiration_date' => $nonExpiredStocks[0]['expiration_date'],
                        'expired' => $nonExpiredStocks[0]['expired'],
                        'food_id' => $nonExpiredStocks[0]['food_id'],
                        'created_at' => $nonExpiredStocks[0]['created_at']->jsonSerialize(),
                        'updated_at' => $nonExpiredStocks[0]['updated_at']->jsonSerialize()
                    ]
                ],
                [
                    'type' => 'stocks',
                    'id' => $nonExpiredStocks[1]['id'],
                    'attributes' => [
                        'quantity' => $nonExpiredStocks[1]['quantity'],
                        'expiration_date' => $nonExpiredStocks[1]['expiration_date'],
                        'expired' => $nonExpiredStocks[1]['expired'],
                        'food_id' => $nonExpiredStocks[1]['food_id'],
                        'created_at' => $nonExpiredStocks[1]['created_at']->jsonSerialize(),
                        'updated_at' => $nonExpiredStocks[1]['updated_at']->jsonSerialize()
                    ]
                ]
            ]
        ]);
    }

    function test_guest_user_can_not_retrieve_all_non_expired_stocks()
    {
        $response = $this->getJson(route('api::v1::stocks.nonExpired'));

        $response->assertUnauthorized();
    }
}
