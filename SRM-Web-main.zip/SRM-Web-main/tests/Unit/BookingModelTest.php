<?php

namespace Tests\Unit;

use App\Models\Booking;
use App\Models\Order;
use App\Models\OrderStatus;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class BookingModelTest extends TestCase
{
    use RefreshDatabase;

    function test_booking_has_name_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'name'
            ]), true
        );
    }

    function test_booking_has_email_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'email'
            ]), true
        );
    }

    function test_booking_has_phone_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'phone'
            ]), true
        );
    }

    function test_booking_has_date_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'date'
            ]), true
        );
    }

    function test_booking_has_people_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'people'
            ]), true
        );
    }

    function test_booking_has_table_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('bookings', [
                'table'
            ]), true
        );
    }

    public function test_booking_has_many_orders()
    {
        $booking = Booking::factory()->create();
        $orderStatus = OrderStatus::factory()->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);

        $this->assertTrue($booking->orders->contains($order));
        $this->assertInstanceOf('Illuminate\Database\Eloquent\Collection', $booking->orders);
    }
}
