<?php

namespace Tests\Unit;

use App\Http\Requests\BookingRequest;
use App\Models\Booking;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

class BookingRequestTest extends TestCase
{
    use RefreshDatabase;

    /**
     * @dataProvider valid_data_provider
     */
    function test_valid_data(array $data)
    {
        $request = new BookingRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertTrue($validator->passes());
    }

    /**
     * @dataProvider invalid_data_provider
     */
    function test_invalid_data(array $data)
    {
        $request = new BookingRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertFalse($validator->passes());
    }

    public function valid_data_provider(): array
    {
        return [
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => str_repeat('A', 1),
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => str_repeat('A', 2),
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => str_repeat('A', Booking::NAME_MAX_LENGTH - 1),
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => str_repeat('A', Booking::NAME_MAX_LENGTH),
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => str_repeat('A', 1) . '@srm.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => str_repeat('A', 2) . '@srm.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => str_repeat('A', Booking::EMAIL_MAX_LENGTH - 9) . '@srm.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => str_repeat('A', Booking::EMAIL_MAX_LENGTH - 8) . '@srm.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => str_repeat('A', 1),
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => str_repeat('A', 2),
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => str_repeat('A', Booking::PHONE_MAX_LENGTH - 1),
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => str_repeat('A', Booking::PHONE_MAX_LENGTH),
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => str_repeat('A', 1)
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => str_repeat('A', 2)
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => str_repeat('A', Booking::TABLE_MAX_LENGTH - 1)
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => str_repeat('A', Booking::TABLE_MAX_LENGTH)
            ]],
        ];
    }

    public function invalid_data_provider(): array
    {
        return [
            [[]],
            [[
                'name' => 'foo'
            ]],
            [[
                'email' => 'foo@foo.com'
            ]],
            [[
                'phone' => '+34 111 111 111'
            ]],
            [[
                'date' => '2022-04-29 21:30:00'
            ]],
            [[
                'people' => 2
            ]],
            [[
                'table' => 'foo table'
            ]],
            [[
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00'
            ]],
            [[
                'name' => '',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => null,
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => str_repeat('A', Booking::NAME_MAX_LENGTH + 1),
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '',
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => null,
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => str_repeat('A', Booking::PHONE_MAX_LENGTH + 1),
                'date' => '2022-04-29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => null,
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '29-04-2022 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022/04/29 21:30:00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21-30-00',
                'people' => 2
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => null
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2.5
            ]],
            [[
                'name' => 'foo',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 'not an integer'
            ]],
            [[
                'name' => 'foo',
                'email' => null,
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => str_repeat('A', Booking::EMAIL_MAX_LENGTH - 7) . '@srm.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'not a valid email',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => 'foo table'
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => null
            ]],
            [[
                'name' => 'foo',
                'email' => 'foo@foo.com',
                'phone' => '+34 111 111 111',
                'date' => '2022-04-29 21:30:00',
                'people' => 2,
                'table' => str_repeat('A', Booking::TABLE_MAX_LENGTH + 1)
            ]]
        ];
    }
}
