<?php

namespace Tests\Unit;

use App\Models\Booking;
use App\Models\Food;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Recipe;
use App\Models\Stock;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CalculateFoodStockTest extends TestCase
{
    use RefreshDatabase;

    public function test_stocks_are_well_calculated_with_stocks_and_single_order()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $recipe = Recipe::factory()->create();
        $recipe->food()->attach($food, ['quantity' => 20]);

        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $order->recipes()->attach($recipe, [
            'quantity' => 2,
            'price' => 19.99
        ]);

        // (350.5 * 2) - (20 * 2) = 661
        $expectedStocks = ($nonExpiredStocks[0]->quantity + $nonExpiredStocks[1]->quantity) - (2 * 20);
        $food->setNonExpiredStocks();
        $this->assertEquals($expectedStocks, $food->refresh()->stock);
    }

    public function test_stocks_are_well_calculated_with_stocks_and_multiple_order()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $recipe = Recipe::factory()->create();
        $recipe->food()->attach($food, ['quantity' => 20]);

        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();

        $orderA = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $orderA->recipes()->attach($recipe, [
            'quantity' => 2,
            'price' => 19.99
        ]);

        $orderB = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);
        $orderB->recipes()->attach($recipe, [
            'quantity' => 3,
            'price' => 19.99
        ]);

        // (350.5 * 2) - (20 * 2) - (3 * 20) = 601
        $expectedStocks = ($nonExpiredStocks[0]->quantity + $nonExpiredStocks[1]->quantity) - (2 * 20) - (3 * 20);
        $food->setNonExpiredStocks();
        $this->assertEquals($expectedStocks, $food->refresh()->stock);
    }

    public function test_stocks_are_well_calculated_with_stocks_and_without_orders()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $expectedStocks = ($nonExpiredStocks[0]->quantity + $nonExpiredStocks[1]->quantity);
        $food->setNonExpiredStocks();
        $this->assertEquals($expectedStocks, $food->refresh()->stock);
    }

    public function test_stocks_are_well_calculated_without_stocks_and_without_orders()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $this->assertEquals(0, $food->stock);
    }
}
