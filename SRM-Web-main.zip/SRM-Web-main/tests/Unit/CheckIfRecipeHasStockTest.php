<?php

namespace Tests\Unit;

use App\Models\Food;
use App\Models\Recipe;
use App\Models\Stock;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CheckIfRecipeHasStockTest extends TestCase
{
    use RefreshDatabase;

    public function test_recipe_has_not_stock_if_it_has_not_food_attached()
    {
        $recipe = Recipe::factory()->create();

        $this->assertFalse($recipe->hasStock());
    }

    public function test_recipe_has_not_stock_if_it_has_food_without_stock_attached()
    {
        $food = Food::factory()->create();

        $recipe = Recipe::factory()->create();
        $recipe->food()->attach($food, ['quantity' => 20]);

        $this->assertFalse($recipe->hasStock());
    }

    public function test_recipe_has_not_stock_if_it_has_food_with_expired_stock_attached()
    {
        $food = Food::factory()->create();

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $recipe = Recipe::factory()->create();
        $recipe->food()->attach($food, ['quantity' => 20]);

        $this->assertFalse($recipe->hasStock());
    }

    public function test_recipe_has_stock_if_it_has_food_with_non_expired_stock_attached()
    {
        $food = Food::factory()->create();

        $nonExpiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 350.50,
            'expiration_date' => \Carbon\Carbon::tomorrow()->timestamp,
            'expired' => false,
            'food_id' => $food->id
        ]);

        $expiredStocks = Stock::factory()->count(2)->create([
            'quantity' => 200.50,
            'expiration_date' => \Carbon\Carbon::yesterday()->timestamp,
            'expired' => true,
            'food_id' => $food->id
        ]);

        $recipe = Recipe::factory()->create();
        $recipe->food()->attach($food, ['quantity' => 20]);

        $this->assertTrue($recipe->hasStock());
    }
}
