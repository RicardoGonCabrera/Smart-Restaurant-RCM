<?php

namespace Tests\Unit;

use App\Http\Middleware\CheckRole;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Laravel\Sanctum\Sanctum;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

class CheckRoleMiddlewareTest extends TestCase
{
    use RefreshDatabase;

    function test_administrators_are_authorized()
    {
        $this->withExceptionHandling();
        Sanctum::actingAs(
            User::factory()->create(['role' => User::ADMINISTRATOR])
        );

        $request = Request::create('/admin', 'GET');

        $middleware = new CheckRole();

        $response = $middleware->handle($request, function () {}, User::ADMINISTRATOR);
        $this->assertEquals(null, $response);

        $response = $middleware->handle($request, function () {}, User::WORKER);
        $this->assertEquals(null, $response);
    }

    function test_workers_are_authorized_only_in_worker_role()
    {
        $this->withExceptionHandling();
        Sanctum::actingAs(
            User::factory()->create(['role' => User::WORKER])
        );

        $request = Request::create('/manager', 'GET');

        $middleware = new CheckRole();

        $response = $middleware->handle($request, function () {}, User::ADMINISTRATOR);
        $this->assertEquals($response->getStatusCode(), Response::HTTP_UNAUTHORIZED);

        $response = $middleware->handle($request, function () {}, User::WORKER);
        $this->assertEquals(null, $response);
    }
}
