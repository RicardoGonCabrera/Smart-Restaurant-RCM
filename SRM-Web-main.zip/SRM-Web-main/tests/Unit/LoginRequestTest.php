<?php

namespace Tests\Unit;

use App\Http\Requests\LoginRequest;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

class LoginRequestTest extends TestCase
{
    use RefreshDatabase;

    /**
     * @dataProvider valid_data_provider
     */
    function test_valid_data(array $data)
    {
        User::factory()->create([
            'email' => 'frank@srm.com'
        ]);

        $request = new LoginRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertTrue($validator->passes());
    }

    /**
     * @dataProvider invalid_data_provider
     */
    function test_invalid_data(array $data)
    {
        User::factory()->create([
            'email' => 'frank@srm.com'
        ]);

        $request = new LoginRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertFalse($validator->passes());
    }

    public function valid_data_provider(): array
    {
        return [
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'device_name' => 'SRM API'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'device_name' => str_repeat('A', 1)
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'device_name' => str_repeat('A', 2)
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'device_name' => str_repeat('A', User::DEVICE_NAME_MAX_LENGTH - 1)
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'device_name' => str_repeat('A', User::DEVICE_NAME_MAX_LENGTH)
            ]]
        ];
    }

    function invalid_data_provider(): array
    {
        return [
            [[]],
            [[
                'email' => 'frank@srm.com',
            ]],
            [[
                'password' => 'password',
            ]],
            [[
                'device_name' => 'SRM API'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
            ]],
            [[
                'email' => 'frank@srm.com',
                'device_name' => 'SRM API'
            ]],
            [[
                'password' => 'password',
                'device_name' => 'SRM API'
            ]],
            [[
                'email' => 'fake_email@srm.com',
                'password' => 'password',
                'device_name' => 'SRM API'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'not the real password',
                'device_name' => null
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'not the real password',
                'device_name' => ''
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'not the real password',
                'device_name' => str_repeat('A', User::DEVICE_NAME_MAX_LENGTH + 1)
            ]]
        ];
    }
}
