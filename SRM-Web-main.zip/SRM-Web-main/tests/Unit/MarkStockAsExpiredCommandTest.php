<?php

namespace Tests\Unit;

use App\Models\Food;
use App\Models\Stock;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MarkStockAsExpiredCommandTest extends TestCase
{
    use RefreshDatabase;

    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function test_stocks_are_marked_as_expired()
    {
        $food = Food::factory()->create();
        $expiredStocks = Stock::factory()->count(5)->create(
            [
                'expiration_date' => \Carbon\Carbon::now()->subDays(30)->format('Y-m-d H:i:s'),
                'food_id' => $food->id
            ]
        );
        $nonExpiredStocks = Stock::factory()->count(5)->create(
            [
                'expiration_date' => \Carbon\Carbon::now()->addDays(30)->format('Y-m-d H:i:s'),
                'food_id' => $food->id
            ]
        );

        $this->artisan('stocks:expire')->assertSuccessful();

        foreach ($expiredStocks as $expiredStock) {
            $this->assertTrue($expiredStock->refresh()->expired);
        }

        foreach ($nonExpiredStocks as $nonExpiredStock) {
            $this->assertFalse($nonExpiredStock->refresh()->expired);
        }
    }
}
