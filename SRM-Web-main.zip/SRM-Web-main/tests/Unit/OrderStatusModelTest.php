<?php

namespace Tests\Unit;

use App\Models\Booking;
use App\Models\Order;
use App\Models\OrderStatus;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class OrderStatusModelTest extends TestCase
{
    use RefreshDatabase;

    function test_order_status_has_status_attribute()
    {
        $this->assertTrue(
            Schema::hasColumns('order_statuses', [
                'status'
            ]), true
        );
    }

    public function test_order_status_has_many_orders()
    {
        $orderStatus = OrderStatus::factory()->create();
        $booking = Booking::factory()->create();
        $order = Order::factory()->create([
            'order_status_id' => $orderStatus->id,
            'booking_id' => $booking->id
        ]);

        $this->assertTrue($orderStatus->orders->contains($order));
        $this->assertInstanceOf('Illuminate\Database\Eloquent\Collection', $orderStatus->orders);
    }

    function test_all_order_statuses_are_in_db()
    {
        $this->seed();

        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_WAITING]);
        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_CONFIRMED]);
        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_CANCELLED]);
        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_IN_PROCESS]);
        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_DELIVERED]);
        $this->assertDatabaseHas('order_statuses', ['status' => OrderStatus::ORDER_STATUS_PAID]);
    }

    function test_can_retrieve_orders_by_their_order_status()
    {
        $this->seed();

        $booking = Booking::factory()->create();

        $waitingOrderStatus = OrderStatus::waiting();
        $waitingOrder = Order::factory()->create([
            'order_status_id' => $waitingOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $confirmedOrderStatus = OrderStatus::confirmed();
        $confirmedOrder = Order::factory()->create([
            'order_status_id' => $confirmedOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $cancelledOrderStatus = OrderStatus::cancelled();
        $cancelledOrder = Order::factory()->create([
            'order_status_id' => $cancelledOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $inProcessOrderStatus = OrderStatus::inProcess();
        $inProcessOrder = Order::factory()->create([
            'order_status_id' => $inProcessOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $deliveredOrderStatus = OrderStatus::delivered();
        $deliveredOrder = Order::factory()->create([
            'order_status_id' => $deliveredOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $paidOrderStatus = OrderStatus::paid();
        $paidOrder = Order::factory()->create([
            'order_status_id' => $paidOrderStatus->id,
            'booking_id' => $booking->id
        ]);

        $this->assertTrue(OrderStatus::waiting()->orders->contains($waitingOrder));
        $this->assertFalse(OrderStatus::waiting()->orders->contains($confirmedOrder));
        $this->assertFalse(OrderStatus::waiting()->orders->contains($cancelledOrder));
        $this->assertFalse(OrderStatus::waiting()->orders->contains($inProcessOrder));
        $this->assertFalse(OrderStatus::waiting()->orders->contains($deliveredOrder));
        $this->assertFalse(OrderStatus::waiting()->orders->contains($paidOrder));

        $this->assertFalse(OrderStatus::confirmed()->orders->contains($waitingOrder));
        $this->assertTrue(OrderStatus::confirmed()->orders->contains($confirmedOrder));
        $this->assertFalse(OrderStatus::confirmed()->orders->contains($cancelledOrder));
        $this->assertFalse(OrderStatus::confirmed()->orders->contains($inProcessOrder));
        $this->assertFalse(OrderStatus::confirmed()->orders->contains($deliveredOrder));
        $this->assertFalse(OrderStatus::confirmed()->orders->contains($paidOrder));

        $this->assertFalse(OrderStatus::cancelled()->orders->contains($waitingOrder));
        $this->assertFalse(OrderStatus::cancelled()->orders->contains($confirmedOrder));
        $this->assertTrue(OrderStatus::cancelled()->orders->contains($cancelledOrder));
        $this->assertFalse(OrderStatus::cancelled()->orders->contains($inProcessOrder));
        $this->assertFalse(OrderStatus::cancelled()->orders->contains($deliveredOrder));
        $this->assertFalse(OrderStatus::cancelled()->orders->contains($paidOrder));

        $this->assertFalse(OrderStatus::inProcess()->orders->contains($waitingOrder));
        $this->assertFalse(OrderStatus::inProcess()->orders->contains($confirmedOrder));
        $this->assertFalse(OrderStatus::inProcess()->orders->contains($cancelledOrder));
        $this->assertTrue(OrderStatus::inProcess()->orders->contains($inProcessOrder));
        $this->assertFalse(OrderStatus::inProcess()->orders->contains($deliveredOrder));
        $this->assertFalse(OrderStatus::inProcess()->orders->contains($paidOrder));

        $this->assertFalse(OrderStatus::delivered()->orders->contains($waitingOrder));
        $this->assertFalse(OrderStatus::delivered()->orders->contains($confirmedOrder));
        $this->assertFalse(OrderStatus::delivered()->orders->contains($cancelledOrder));
        $this->assertFalse(OrderStatus::delivered()->orders->contains($inProcessOrder));
        $this->assertTrue(OrderStatus::delivered()->orders->contains($deliveredOrder));
        $this->assertFalse(OrderStatus::delivered()->orders->contains($paidOrder));

        $this->assertFalse(OrderStatus::paid()->orders->contains($waitingOrder));
        $this->assertFalse(OrderStatus::paid()->orders->contains($confirmedOrder));
        $this->assertFalse(OrderStatus::paid()->orders->contains($cancelledOrder));
        $this->assertFalse(OrderStatus::paid()->orders->contains($inProcessOrder));
        $this->assertFalse(OrderStatus::paid()->orders->contains($deliveredOrder));
        $this->assertTrue(OrderStatus::paid()->orders->contains($paidOrder));
    }
}
