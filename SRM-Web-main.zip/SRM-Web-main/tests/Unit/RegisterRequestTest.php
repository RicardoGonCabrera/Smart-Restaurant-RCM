<?php

namespace Tests\Unit;

use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

class RegisterRequestTest extends TestCase
{
    use RefreshDatabase;

    /**
     * @dataProvider valid_data_provider
     */
    public function test_valid_data(array $data)
    {
        $request = new RegisterRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertTrue($validator->passes());
    }

    /**
     * @dataProvider invalid_data_provider
     */
    public function test_invalid_data(array $data)
    {
        User::factory()->create([
            'email' => 'frank@srm.com'
        ]);

        $request = new RegisterRequest();

        $validator = Validator::make($data, $request->rules());

        $this->assertFalse($validator->passes());
    }

    public function valid_data_provider(): array
    {
        return [
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => str_repeat('A', 1),
                'email' => str_repeat('A', 1) . '@srm.com',
                'password' => str_repeat('A', 1),
                'password_confirmation' => str_repeat('A', 1)
            ]],
            [[
                'name' => str_repeat('A', 2),
                'email' => str_repeat('A', 2) . '@srm.com',
                'password' => str_repeat('A', 2),
                'password_confirmation' => str_repeat('A', 2)
            ]],
            [[
                'name' => str_repeat('A', User::NAME_MAX_LENGTH - 1),
                'email' => str_repeat('A', User::EMAIL_MAX_LENGTH - 9) . '@srm.com',
                'password' => str_repeat('A', User::PASSWORD_MAX_LENGTH - 1),
                'password_confirmation' => str_repeat('A', User::PASSWORD_MAX_LENGTH - 1)
            ]],
            [[
                'name' => str_repeat('A', User::NAME_MAX_LENGTH),
                'email' => str_repeat('A', User::EMAIL_MAX_LENGTH - 8) . '@srm.com',
                'password' => str_repeat('A', User::PASSWORD_MAX_LENGTH),
                'password_confirmation' => str_repeat('A', User::PASSWORD_MAX_LENGTH)
            ]]
        ];
    }

    public function invalid_data_provider(): array
    {
        return [
            [[]],
            [[
                'name' => 'Frank',
            ]],
            [[
                'email' => 'frank@srm.com',
            ]],
            [[
                'password' => 'password',
            ]],
            [[
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com'
            ]],
            [[
                'name' => 'Frank',
                'password' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'password_confirmation' => 'password'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password_confirmation' => 'password'
            ]],
            [[
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => 'password'
            ]],
            [[
                'name' => null,
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => null,
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => null,
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => null
            ]],
            [[
                'name' => '',
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => '',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => '',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => ''
            ]],
            [[
                'name' => str_repeat('A', User::NAME_MAX_LENGTH + 1),
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => str_repeat('A', User::EMAIL_MAX_LENGTH - 7) . '@srm.com',
                'password' => 'password',
                'password_confirmation' => 'password'
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => str_repeat('A', User::PASSWORD_MAX_LENGTH + 1),
                'password_confirmation' => str_repeat('A', User::PASSWORD_MAX_LENGTH + 1)
            ]],
            [[
                'name' => 'Frank',
                'email' => 'frank@srm.com',
                'password' => 'password',
                'password_confirmation' => 'not the same password'
            ]],
        ];
    }
}
